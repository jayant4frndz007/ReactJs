const isState={
    message:'',
    signal:false
   }

   const JsonLoginData={
    username:"hruday@gmail.com",
    password :'hruday123'
   }

const reducer1 =(state=isState,action)=>{
    console.log(action);
    if(action.type === 'LOGIN'){
        if(action.data.user === JsonLoginData.username && action.data.pass === JsonLoginData.password){
            return {
                message:'Successful Login',
                signal:true
            };
        }
        return {
            message:'Invalid User ID', 
            signal:false 
        };
       
    }
    if(action.type === 'MISSING'){
        if(action.data.user === ''){
            return {
                message:'Please Give User Name',
                signal:false
            };
        }else{

        
        return {
            message:'Please Give password', 
            signal:false 
        };
    }
       
    }
    return state;
}

export default reducer1;